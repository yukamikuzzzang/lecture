#include <string>

#ifndef ACCOUNT_H
#define ACCOUNT_H

using namespace std;
class Account{
	private:
		string name;
		int id;
		int money;
	public:
		int deposit(int d);
		int withdraw(int e);
		int getInquiry();
		string getOwner();
		Account(string a,int b, int c);
}; 

#endif
