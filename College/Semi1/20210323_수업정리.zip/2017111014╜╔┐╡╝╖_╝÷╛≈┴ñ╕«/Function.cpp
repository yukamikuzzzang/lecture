#include <string>
#include <iostream>
#include "account.h"

#ifndef FUNCTION_H
#define FUNCTION_H
using namespace std;

Account::Account(string a,int b,int c){
	name = a;
	id = b;
	money = c;
}
int Account::deposit(int d){
	return money += d;
	
}
int Account::withdraw(int e){
	return money -= e;
	}
int Account::getInquiry(){
	return money;
}
string Account::getOwner(){
	return name;
}

#endif
