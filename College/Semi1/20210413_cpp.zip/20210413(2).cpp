#include<iostream>
#include<string>
#include <ctime> //<time.h>
#include <cstdlib> //<stdlib.h>

using namespace std;

// +(3)
/*
class Circle {
private:
	int radius;
public:
	Circle();
	Circle(int r);
	~Circle();
	
	double getArea() { return 3.14*radius*radius;}
	int getRadius() { return radius;}
	void setRadius(int radius) { this -> radius = radius;}
};

Circle::Circle(){
	radius = 1;
	cout << "������ ���� radius = "<<radius<<endl;
}

Circle::Circle(int radius){
	this -> radius = radius;
	cout<<"������ ���� radius = " << radius << endl; 
}

Circle::~Circle(){
	cout<<"�Ҹ��� ���� radius = "<< radius << endl;
}
void Increase1(Circle c){
	int r = c.getRadius();
	c.setRadius(r+1);
}
void Increase2(Circle *c){
	int r = c -> getRadius();
	c -> setRadius(r+1);
}
void Increase3(Circle &c){
	int r = c.getRadius();
	c.setRadius(r+1);
}

int main(){
	Circle waffle(30);
	cout <<"/"<< waffle.getRadius() <<endl;	
	Increase1(waffle);
	cout <<"/"<< waffle.getRadius() <<endl;	
	
	
	Circle donut(20);	
	cout <<"|"<< donut.getRadius() <<endl;	
	Increase2(&donut);
	cout <<"|"<< donut.getRadius() <<endl;	
	
	Circle pizza(10);
	cout <<"\'"<< pizza.getRadius() <<endl;
	Increase3(pizza);
	cout <<"\'"<< pizza.getRadius() <<endl;	
	//cout << waffle.getRadius() <<endl;
	return 0;
} 
*/

//(4)
void MAXS(int *p, int &max, int size){
//	//int i = 0;
//	max = p[0];
	
	for (int i; i< size; i++){
		if( max < p[i]){
			max = p[i];
		//cout<<max<<endl;
	}
}
}

void MINS(int *p, int &min, int size){
//	//int i = 0;
//	min = p[0];
	
	for (int i; i< size ; i++){
		if( min > p[i]){
			min = p[i];
		//cout<<max<<endl;
	}
}
}


int main(){
	//call by reference
	//������ �� 10���� �߻��Ͽ� �ִ밪�� �ּҰ� ���ϱ� 
	const int size = 10;
	srand(time(NULL));
	int ar[size], MAX, MIN;
	int r = rand();		//�׶��׶� �ٸ� ��������.. 

	for (int i=0;i<10;i++){
		ar[i] = rand() % 100;	
		cout<<ar[i]<<endl;	
	}	
	 
	MAXS(ar,MAX, size);
	MINS(ar,MIN, size);
	cout<<"�ִ밪="<<MAX<<endl;
	cout<<"�ּҰ�="<<MIN<<endl;
	
	return 0;
} 
