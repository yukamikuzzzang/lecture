#include <string>
using namespace std;

#ifndef CAL_H
#define CAL_H

class Add{
	private:
		int op1;
		int op2;
		int value;
	public:
		Add(int a,int b);
		int a();
};

class Sub{
	private:
		int op1;
		int op2;
		int value;
	public:
		Sub(int c,int d);
		int s();
};

class Mul{
	private:
		int op1;
		int op2;
		int value;
	public:
		Mul(int e,int f);
		int m();
};

class Div{
	private:
		int op1;
		int op2;
		int value;
	public:
		Div(int g,int h);
		int d();
};


#endif
