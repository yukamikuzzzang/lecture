#include <iostream>
#include <string>
using namespace std;

#include "calcul.cpp"
/*
class Add{
	private:
		int op1;
		int op2;
		int value;
	public:
		Add(int a,int b);
		int a();
};

class Sub{
	private:
		int op1;
		int op2;
		int value;
	public:
		Sub(int c,int d);
		int s();
};

class Mul{
	private:
		int op1;
		int op2;
		int value;
	public:
		Mul(int e,int f);
		int m();
};

class Div{
	private:
		int op1;
		int op2;
		int value;
	public:
		Div(int g,int h);
		int d();
};

Add::Add(int a, int b){
 	op1 = a;
 	op2 = b;
 	value = op1 + op2;
}
Sub::Sub(int c, int d){
	op1 = c;
 	op2 = d;
 	value = op1 - op2;
	
}
Mul::Mul(int e, int f){
	op1 = e;
 	op2 = f;
 	value = op1 * op2;
}
Div::Div(int g, int h){
	op1 = g;
 	op2 = h;
 	value = op1 / op2;
}

int Add::a() {
	return value;
}
int Sub::s() {
	
	return value;
}
int Mul::m() {
	
	return value;
}
int Div::d() {
	if(op1==0){
		if(op2==0){
		 	cout<<"������ �Ұ�";
		}
	}else{
	value = op1/op2;

	return value;
	}
}
	
	
	
*/
int main() {
	int num1 = 1, num2 =1;
	char opt;
	
	cout<<"�� ������ �����ڸ� �Է��ϼ���.";
	cin>>num1>>num2>>opt; 
	
	if(opt =='+'){
		Add add(num1,num2);
		cout<<add.a();
	}
	else if(opt == '-'){
		Sub sub(num1,num2);
		cout<<sub.s();
	}else if (opt == '*'){
		Mul mul(num1,num2);
		cout<<mul.m();
	}else{
		if(num1 == 0 || num2 == 0){
			cout << "�ٽ���";
		}else{
			Div div(num1,num2);
			cout<<div.d();
		}
	}

	
	return 0;
}
