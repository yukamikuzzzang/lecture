#include <string>
#include <iostream>

#include "cal.h"
using namespace std;


Add::Add(int a, int b){
 	op1 = a;
 	op2 = b;
 	value = op1 + op2;
}
Sub::Sub(int c, int d){
	op1 = c;
 	op2 = d;
 	value = op1 - op2;
	
}
Mul::Mul(int e, int f){
	op1 = e;
 	op2 = f;
 	value = op1 * op2;
}
Div::Div(int g, int h){
	op1 = g;
 	op2 = h;
 	value = op1 / op2;
}

int Add::a() {
	return value;
}
int Sub::s() {
	
	return value;
}
int Mul::m() {
	
	return value;
}
int Div::d() {
	if(op1==0){
		if(op2==0){
		 	cout<<"������ �Ұ�";
		}
	}else{
	value = op1/op2;

	return value;
	}
}
